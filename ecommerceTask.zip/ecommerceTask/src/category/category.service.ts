import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { CategoryEntity } from './entities/category.entity';
import { CategoryDto } from './Dto/category-dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DeleteResult, UpdateResult } from 'typeorm';
import { CartEntity } from 'src/cart/entities/cart.entity';

@Injectable()
export class CategoryService {
  constructor(
    @InjectRepository(CategoryEntity)
    private catRepository: Repository<CategoryEntity>,
  ) {}

  async create(category: CategoryDto,req: any): Promise<object> {
    const categoryName : string = category.categoryName
    const findCategory = await this.catRepository.findOne({where:{categoryName}})
    if(findCategory){
      throw new BadRequestException('category is available so go to add product')
    }
    else{
      const createdCategory = await this.catRepository.create({
        categoryName: category.categoryName,
        userId: req.user.id
      });
      return await this.catRepository.save(createdCategory);

    }
   
  }

  async update(id: number, attrs: Partial<CategoryEntity>,req: { user: { id: number; }; }){
    const updateCategory = await this.catRepository.findOne({ where: { id } });
    if (!updateCategory) {
      throw new NotFoundException('categoryId not found');
    }
    console.log('updateCategory',updateCategory);
    Object.assign(updateCategory, attrs);
    updateCategory.categoryName = attrs.categoryName
    updateCategory.userId = req.user.id
    return this.catRepository.save(updateCategory);
  }

  async findAll(): Promise<CategoryEntity[]> {
    return this.catRepository.find();
  }

  async findOne(id: number): Promise<CategoryEntity> {
    const category = await this.catRepository.findOne({ where: { id } });
    if(category){
      return category;

    }else{
      throw new NotFoundException('CategoryId was not Found')
    }
  }


  async delete(id: number): Promise<any> {
    const category = await this.catRepository.findOne({ where: { id } });
    if (!category) {
      throw new BadRequestException('invalid category id');
    } else {
      await this.catRepository.remove(category);
    }
    return 'successfully deleted';
  }
}
