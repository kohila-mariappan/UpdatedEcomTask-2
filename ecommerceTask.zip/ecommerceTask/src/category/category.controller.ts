import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  ValidationPipe,
  UseGuards,
  Request
} from '@nestjs/common';
import { CategoryEntity } from './entities/category.entity';
import { CategoryService } from './category.service';
import { CategoryDto } from './Dto/category-dto';
import { AuthGuard } from '@nestjs/passport';
import { JwtAuthGuard } from 'src/auth/guard/auth.gurd';

@Controller('category')
export class CategoryController {
  constructor(private readonly catService: CategoryService) {}
  @UseGuards(JwtAuthGuard)
  @Post()
  async create(@Body() categoryDto: CategoryDto,@Request() req) : Promise<object> {
    // const userId = req.user.id
    // categoryDto.userId = userId;
    return await this.catService.create(categoryDto,req);
  }

  @UseGuards(JwtAuthGuard)
  @Get()
  async findAll(): Promise<CategoryEntity[]> {
    return this.catService.findAll();
  }

  @UseGuards(JwtAuthGuard)
  @Get(':id')
  findOne(@Param('id') id: number) {
    return this.catService.findOne(id);
  }



  @UseGuards(JwtAuthGuard)
  @Put(':id')
  update(@Param('id') id: number, @Body() updateCatDto: CategoryDto,@Request() req) {
    return this.catService.update(id,updateCatDto,req);
  }

  @UseGuards(JwtAuthGuard)
  @Delete(':id') remove(@Param('id') id: number) {
    return this.catService.delete(id);
  }
}
