import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderController } from './controller/order.controller';
import { OrderEntity } from './entities/order.entity';
import { OrderService } from './service/order.service';
import { CartEntity } from 'src/cart/entities/cart.entity';
import { ProductEntity } from 'src/product/entities/product.entity';
import { PaymentEntity } from 'src/payment/entity/payment.entity';
import { OrderControllerV1 } from './controller/order.controllerV1';
import { OrderServiceV1 } from './service/order.serviceV1';
@Module({
  imports: [TypeOrmModule.forFeature([OrderEntity,CartEntity,PaymentEntity,ProductEntity])],
  controllers: [OrderController,OrderControllerV1],
  providers: [OrderService,OrderServiceV1],
})
export class OrderModule {}
