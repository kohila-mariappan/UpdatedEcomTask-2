import { Entity, Column, PrimaryGeneratedColumn,OneToMany,ManyToOne,JoinColumn} from 'typeorm';
import { ProductEntity } from 'src/product/entities/product.entity';

@Entity()
export class OrderEntity {
  @PrimaryGeneratedColumn()
  id: number;
  @Column()
  productId: number;
  @Column()
  userId: number;
  @Column()
  amount: number;
  @Column()
  deliveryCharge: number;
  @Column()
  totalAmount: number;
  @Column()
  paymentStatus: string;
  @Column()
  orderStatus: string;
  @OneToMany(type => ProductEntity, item => item.id)
  items: ProductEntity[];

  
}
