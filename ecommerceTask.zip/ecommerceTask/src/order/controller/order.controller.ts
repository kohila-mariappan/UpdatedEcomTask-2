import { Controller, Post, Body, Get, Param, UseGuards, Request, Patch } from '@nestjs/common';
import { CreateOrderDto } from '../dto/createOrder.dto';
import { OrderService } from '../service/order.service';
import { AuthGuard } from '@nestjs/passport';
import { JwtAuthGuard} from 'src/auth/guard/auth.gurd';

@Controller('order')
export class OrderController {
  constructor(private orderService: OrderService) {}
  @UseGuards(JwtAuthGuard)
  @Post('/add')
  async createOrder(@Body() body: CreateOrderDto,@Request() req): Promise<object> {
    return await this.orderService.createOrder(body,req);
  }
  @UseGuards(JwtAuthGuard)
  @Get('')
  async myOrders(@Request() req): Promise<Object> {
    return await this.orderService.myOrders(req);
  }
 
  
  @UseGuards(JwtAuthGuard)
  @Get('/orderStatus/:id')
  async orderStatus(@Param('id') id: number): Promise<object> {
    console.log('orderId',id)
    return await this.orderService.orderStatus(id);
  }

  @UseGuards(JwtAuthGuard)
  @Patch('/cancel/:id')
  async orderCancel(@Param('id') id: number,@Request() req,@Body() body): Promise<string> {
    console.log('orderId',req.user.id)
    return await this.orderService.orderCancel(id,body,req);
  }

  

}
