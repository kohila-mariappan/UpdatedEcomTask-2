import { BadRequestException, Injectable } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from 'src/user/entities/user.entity';
import { UpdateUserDto } from 'src/user/Dtos/updateUser.dto';
import { NewUser } from '../user.interface';
import { CreateUserDto } from 'src/user/Dtos/createUserDto';

// interface CreateUser{
//   firstName:string,
//         lastName: string,
//         email: string,
//         gender: string,

// }

@Injectable()
export class AuthServiceV1 {
  //[x: string]: any;
  constructor(
    @InjectRepository(User) private repo: Repository<User>,
    private jwt: JwtService,private userInterface : NewUser,
  ) {}

  async create(body: CreateUserDto): Promise<CreateUserDto> {
    const email: string = body.email;
    const newUser = await this.repo.createQueryBuilder("user")
    .select()
    .where('user.email=:email',{email : email})
    .getOne()
    console.log('newUser',newUser);
    if (newUser) {
      throw new BadRequestException('User already registered');
    } else {
      const password = await this.passwordEncryption(body.password);


      const newUser = await this.repo.create({
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        gender: body.gender,
        password: password,
      });

      return await this.repo.save(newUser)
      
      // const savedUser : CreateUser= {
      //   firstName: newUser.firstName,
      //   lastName: newUser.lastName,
      //   email: newUser.email,
      //   gender: newUser.gender
      // }
      // return savedUser;
    }
  }

  
  async validateUser(email: string, password: string): Promise<any> {
    //console.log(email,password)
    const user = await this.repo.findOne({ where: { email } });
    //console.log('vuser',user)
    if (user) {
      const result = await bcrypt.compare(password, user.password);
      if (result) {
        return user;
      } else {
        throw new BadRequestException('incorrect password');
      }
    } else {
      throw new BadRequestException('invalid email');
    }
  }

  async signIn(body): Promise<object> {
    const users = await this.validateUser(body.email, body.password);
    console.log(users)                                         
    if (users) {
      const payload = {
        userId:users.id,
        email: users.email, 
      };
      const token = this.jwt.sign(payload);
      console.log('token', token);
      const data  = {
        email: users.email,
        password:users.password, 
        token:token
      }
      console.log('data',data)
      return data
  
    } else {
      throw new BadRequestException('error');
    }
  }
  async resetPassword(body: UpdateUserDto, id: number): Promise<string> {
    const user = await this.repo.findOne({ where: { id } });
    if (!user) {
      throw new BadRequestException('invalid user email');
    } else {
      const password: string = await this.passwordEncryption(body.password);
      user.password = password;
      await this.repo.save(user);
      return 'password reset sucessfully'
    }
  }
  async passwordEncryption(password: string): Promise<string> {
    const hash : string= await bcrypt.hash(password, 10);
    return hash;
  }
  async validation(userId:number, email:string):Promise<any>{
    console.log(userId,email)
    const user = await this.repo.findOne({where : {id:userId}});
    console.log('userval',user)
    if(user.email===email){
      return user
    }
    else{
      return 'invalid email'
    }
  }
}
