import {
    Body,
    Controller,
    Param,
    Patch,
    Post,
    UseGuards,
    Request
  } from '@nestjs/common';
import { CreateUserDto } from 'src/user/Dtos/createUserDto';
  import { UpdateUserDto } from 'src/user/Dtos/updateUser.dto';
  import { JwtAuthGuard } from '../guard/auth.gurd';
import { AuthServiceV1 } from '../Service/auth.serviceV1';
  
  @Controller('v1/auth')
  export class AuthControllerV1 {
    constructor(private authService: AuthServiceV1) {}
  
    @Post('/signUp')
    async studentSignUp(@Body() body: CreateUserDto): Promise<CreateUserDto> {
      // console.log(body);
      return await this.authService.create(body);
    }
  
    @Post('/signIn')
    async signIn(@Body() body) :Promise<object> {
      return this.authService.signIn(body);
    }
  
    @UseGuards(JwtAuthGuard)
    @Patch('/resetPassword/:id')
    resetPassword(@Param('id') id: number, @Body() body: UpdateUserDto) {
      return this.authService.resetPassword(body, id);
    }
  }
  