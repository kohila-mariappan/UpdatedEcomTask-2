import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';
import { AuthController } from './Contoller/auth.controller';
import { AuthService } from './Service/auth.service';
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from './auth.constant';
import { PassportModule } from '@nestjs/passport';
import { JwtStrategy } from './jwt.strategy';
import { LocalStrategy } from './local.strategy';
import {JwtAuthGuard} from './guard/auth.gurd'
import { AuthServiceV1 } from './Service/auth.serviceV1';
import { AuthControllerV1 } from './Contoller/auth.controllerV1';



@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '1h' },
    }),
    PassportModule,
  ],
  controllers: [AuthController,AuthControllerV1],
  providers: [AuthService, JwtStrategy, LocalStrategy, JwtAuthGuard,AuthServiceV1],
})
export class AuthModule {}
