export const jwtConstants = {
  secret: 'EA386EDC6B43F',
};
