import { Strategy } from 'passport-jwt';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ExtractJwt } from 'passport-jwt';
import { jwtConstants } from './auth.constant';
import { AuthService } from './Service/auth.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private authService:AuthService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: jwtConstants.secret,
    });
  
  }

  async validate(payload){
    const user = await this.authService.validation(payload.userId, payload.email);
    //console.log('jwtStrategyuser',user);
    if (!user) {
      throw new UnauthorizedException();
    }
    return user;
  }
  }

  

