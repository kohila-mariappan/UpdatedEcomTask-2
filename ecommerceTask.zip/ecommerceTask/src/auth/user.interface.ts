export interface NewUser{
    firstName: string,
    lastName:string,
    email: string,
    gender: string
}

export interface LoginUser extends NewUser{
    token :string,
    user:NewUser
}