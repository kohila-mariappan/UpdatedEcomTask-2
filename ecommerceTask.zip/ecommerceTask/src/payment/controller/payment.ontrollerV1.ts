import { Controller,Param, UseGuards, Request, Post, Body, Get } from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/guard/auth.gurd';
import { CreatePaymentDto } from '../Dto/payment.Dto';
import { PaymentServiceV1 } from '../service/payment.serviceV1';


@Controller('v1/payment')
export class PaymentControllerV1 {
    constructor(private paymentService : PaymentServiceV1){}
@UseGuards(JwtAuthGuard)
@Post()
async createPayment(@Body() body:CreatePaymentDto,@Request() req):Promise<string>{
    return await this.paymentService.createPayment(body,req)
}
@UseGuards(JwtAuthGuard)
@Get('/status')
async paymentStatus(@Request() req): Promise<object> {
  return await this.paymentService.paymentStatus(req);
}
    

}
