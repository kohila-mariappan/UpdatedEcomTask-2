import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CartEntity } from 'src/cart/entities/cart.entity';
import { PaymentEntity } from './entity/payment.entity';
import { PaymentController } from './controller/payment.controller';
import { PaymentService } from './service/payment.service';
import { PaymentControllerV1 } from './controller/payment.ontrollerV1';
import { PaymentServiceV1 } from './service/payment.serviceV1';


@Module({
  imports: [TypeOrmModule.forFeature([CartEntity,PaymentEntity])],

  controllers: [PaymentController,PaymentControllerV1],
  providers: [PaymentService,PaymentServiceV1]
})
export class PaymentModule {}
