import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CartController } from './controller/cart.controller';
import { CartEntity } from './entities/cart.entity';
import {CartService} from './service/cart.service';
import { User } from 'src/user/entities/user.entity';
import { ProductEntity } from 'src/product/entities/product.entity';
import { CartControllerV1 } from './controller/cart.controllerV1';
import { CartServiceV1 } from './service/cart.serviceV1';

@Module({
  imports: [TypeOrmModule.forFeature([CartEntity, User, ProductEntity])],
  controllers: [CartController,CartControllerV1],
  providers: [CartService,CartServiceV1],
})
export class CartModule {}
