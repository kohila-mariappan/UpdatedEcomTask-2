import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserService } from './user.service';
import { User } from './entities/user.entity';
import { UserController } from './user.controller';
import { MaileService } from './mailer.service';
import { JwtStrategy } from 'src/auth/jwt.strategy';
import { AuthServiceV1 } from 'src/auth/Service/auth.serviceV1';
import { JwtService } from '@nestjs/jwt';
import { AuthService } from 'src/auth/Service/auth.service';

@Module({
  imports: [TypeOrmModule.forFeature([User])],
  controllers: [UserController],
  providers: [UserService, MaileService, JwtStrategy, JwtService, AuthService, AuthServiceV1],
})
export class UserModule {}
