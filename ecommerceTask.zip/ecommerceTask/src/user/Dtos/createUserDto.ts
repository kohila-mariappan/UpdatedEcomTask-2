import { IsEmail,IsOptional, IsString } from 'class-validator';

export class CreateUserDto {
  @IsString()
  firstName: string;

  @IsString()
  lastName: string;
  @IsEmail()
  email:string

  @IsString()
  gender: string;

  @IsOptional()
  @IsString()
  password: string;
}
