import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
  Request,
  UseGuards,
} from '@nestjs/common';
import { ProductService } from './product.service';
import { CreateProductDto } from './dto/create-product.dto';
import { ProductEntity } from './entities/product.entity';
import { AuthGuard } from '@nestjs/passport';
import { JwtAuthGuard } from 'src/auth/guard/auth.gurd';

@Controller('product')
export class ProductController {
  constructor(private readonly productService: ProductService) {}
  @UseGuards(JwtAuthGuard)
  @Post()
  async create(@Body() body: CreateProductDto,@Request() req): Promise<any> {
    return await this.productService.create(body,req);
  }

  @UseGuards(AuthGuard('jwt'))
  @Get('/category/:categoryId')
  async CategoryAllProducts(@Param('categoryId') categoryId:number): Promise<ProductEntity[]> {
    return await this.productService.CategoryAllProducts(categoryId);
  }

  @UseGuards(AuthGuard('jwt'))
  @Get()
  async GetAllProducts(@Request() req) : Promise<ProductEntity[]> {
    return await this.productService.GetAllProducts(req.user);
  }

  @UseGuards(AuthGuard('jwt'))
  @Get(':id')
  findOne(@Param('id') id: number,@Request() req) {
    return this.productService.findOne(id,req.user);
  }
 
  @UseGuards(AuthGuard('jwt'))
  @Put(':id')
  update(@Param('id') id: number, @Body() updateCatDto: CreateProductDto,@Request() req) {
    return this.productService.update(id,updateCatDto,req);
  }

  
  @UseGuards(AuthGuard('jwt'))
  @Delete(':id') remove(@Param('id') id: number,@Request() req) {
    return this.productService.delete(id,req);
  }
}
