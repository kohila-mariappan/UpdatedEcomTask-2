import { Entity, Column, PrimaryGeneratedColumn ,JoinColumn, OneToMany} from 'typeorm';
import { CartEntity } from 'src/cart/entities/cart.entity';
import { IsOptional } from 'class-validator';
@Entity()
export class ProductEntity {
  @PrimaryGeneratedColumn()
  id: number;
  @Column()
  name: string;
  @Column()
  description: string;
  @Column()
  image: string;
  @Column()
  price: number;
  
  @Column()
  userId: number;

  @Column()
  categoryId: number;
  @OneToMany(type => CartEntity, cart => cart.id)
   @JoinColumn()
   cart: CartEntity[]

}
